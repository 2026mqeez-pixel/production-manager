مشروع محمد القيز - Android WebView

هذه حزمة مشروع Android Studio (مصدر التطبيق)، وليست ملف APK جاهزاً بعد.

طريقة إنشاء APK:
1) ثبّت Android Studio على كمبيوتر Windows أو Mac أو Linux.
2) افتح Android Studio واختر Open ثم اختر مجلد ManagerProductionWebView.
3) انتظر اكتمال Gradle Sync وتنزيل مكونات Android SDK المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد ملف APK غالباً في:
   app/build/outputs/apk/debug/app-debug.apk
6) انقل APK إلى هاتف Samsung وافتحه للتثبيت. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

ملاحظات:
- التطبيق يفتح ملف HTML محلياً داخل WebView ولا يحتاج اتصال إنترنت أثناء الاستخدام.
- بيانات التطبيق محفوظة محلياً داخل WebView (localStorage).
- النسخ الاحتياطي والتصدير من داخل التطبيق يحفظان الملف في مجلد Downloads.
- استعادة النسخة الاحتياطية تتيح اختيار ملف من الهاتف.
- هذه نسخة أولية من مشروع WebView. يجب بناء APK واختباره على الهاتف قبل الاعتماد التشغيلي.


بناء سحابي من الهاتف (دون تثبيت Android Studio):
1) أنشئ حساباً مجانياً في GitHub ثم أنشئ مستودعاً جديداً (Private).
2) فك ضغط هذا المشروع في الهاتف. ارفع ملفات ومجلدات المشروع إلى المستودع مع الحفاظ على المسارات.
3) تأكد من رفع الملف المخفي .github/workflows/build.yml إلى المسار نفسه داخل المستودع.
4) افتح تبويب Actions واختر Build Android APK ثم Run workflow.
5) بعد نجاح البناء افتح نتيجة التشغيل، ثم نزّل Artifact باسم Manager-Production-Smart-APK.
6) فك ضغط Artifact لتحصل على app-debug.apk ثم ثبّته على الهاتف.
ملاحظة: البناء يتم على خوادم GitHub؛ تنزيل Android SDK يتم على الخادم وليس على باقة هاتفك.
